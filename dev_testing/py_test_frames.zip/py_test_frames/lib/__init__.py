#remdinder to use the relative "." here otherwise it's not "part of the package"
#from .[filename] import *
from .py_dash_defines import *
from .py_dash_SCRNdefines import *
from .py_dash_drawFuncs import *