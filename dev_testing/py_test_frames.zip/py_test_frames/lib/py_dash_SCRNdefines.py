#screen defines portion of the pydash

#-----------------------------Library Inputs-----------------------------
"""
        button layout
        
        1   |               |   4
            |               |
        2   |    screen     |   5
            |               |
        3   |               |   6

        1- Page up
        2- Settings
        3- Page Down
        4- Scroll up
        5- Enter/select
        6- Scroll Down
"""
dash_btn1 = 15
dash_btn2 = 16
dash_btn3 = 17
dash_btn4 = 18
dash_btn5 = 19
dash_btn6 = 20

#-----------------------------classes-----------------------------
#class for screen control
class screen_info:
    def __init__(self,  state, light_pwm):
        #-----CAN data values
        self.state = state                  #current screen state/display
        self.light_pwm = light_pwm          #backlight PWM, in percent
        self.wndws = []                     #all defined windows
        self.num_wndws = 0                  #number of defined windows
   
    #add a window to the list
    def add_window(self, new_wndw):
        self.wndws.append(new_wndw)         #append window to list of windows
        self.num_wndws += 1                 #increment number of windows

    #open/focus on the target window
    def open_window(self, tgt_wndw):
        self.state = tgt_wndw               #set the current window state index
        '''
            TODO: For w, all windows in list
                        if w = tgt_window then: w.deiconify()
                        else: w.withdraw()
        '''

#default screen values
scrn = screen_info(0, 100)          #default (0) window, 100% PWM backlight

#-----------------------------Window specific functions-----------------------------
