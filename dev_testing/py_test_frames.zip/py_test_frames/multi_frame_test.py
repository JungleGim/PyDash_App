"""
multi window test
------------
test script for setting up the basics of a multi window tk envinronment
Notes
-------------

"""

#-----------------------------imports
from lib import *                       #import files as defined in __init__ file of 'lib' directory

#-----------------------------support functions


#-----------------------------init functions


#-----------------------------class for default window
''' @brief: Root window
    @notes: nothing specifically is done here but is the main TK instance
'''
class RootWindow(tk.Tk):
    def __init__(self):
        tk.Tk.__init__(self)

        #NOTE: Can't use the "frame_change" function to open one since the self.frame object hasn't been defined yet.
        self.frame = FirstFrame(self)   #open default frame
        self.frame.pack()               #pack contents

    #NOTE: the defined functions here can be handled by the frames with master.[func]
    ''' @brief: Change Frame
        @notes: switches the from displayed in the root window 
                ~note that this can ONLY be used if the "self.frame" object already has been created
    '''
    def frame_change(self, new_frame):
        self.frame.pack_forget()        # delete currrent frame
        self.frame = new_frame(self)    # update to the passed "new_frame"
        self.frame.pack()               # pack the contents
#end of the root window        

class FirstFrame(tk.Frame):
    #NOTE: setting as master=None makes this frame a parent of the root window that contain the main TK instance
    def __init__(self, master=None, **kwargs):
        tk.Frame.__init__(self, master, **kwargs)

        #NOTE: using the master.[property] here updates the MASTER window that the current frame is housed in.
        master.title("Root Window")
        master.geometry("300x200")

        lbl = tk.Label(self, text='Root Window')
        lbl.pack()

        #NOTE: Using this button do demonstrate inline wrapped using lambda to local function
        #btn1 = tk.Button(self, text="Go to Second frame", command=self.frame_goto_second)
        btn1 = tk.Button(self, text="Go to Second frame", command= lambda: self.frame_goto(SecondFrame))
        btn1.pack()

        btn2 = tk.Button(self, text="Go to Third frame", command=self.frame_goto_third)
        btn2.pack()

        #NOTE: Same as btn1 but just pointing back to master for the labmda
        btn4 = tk.Button(self, text="Go to Third frame - different", command=lambda: master.frame_change(ThirdFrame))
        btn4.pack()

        btn3 = tk.Button(self, text="Cancel", command=self.quit)
        btn3.pack()

    def frame_goto(self, goto_frame):
        self.master.frame_change(goto_frame)
    
    def frame_goto_third(self, event=None):
        self.master.frame_change(ThirdFrame)
#end of the first frame            

class SecondFrame(tk.Frame):
    def __init__(self, master=None, **kwargs):
        tk.Frame.__init__(self, master, **kwargs)
        #NOTE: see changing the title and geometry here updates the primary window
        master.title("Second Frame")
        master.geometry("300x200")

        lbl = tk.Label(self, text='Second Frame')
        lbl.pack()
        btn = tk.Button(self, text="Back To Main", command=self.frame_goto_main)
        btn.pack()
    
    #NOTE: see how these are local functions to just "second frame"
    def frame_goto_main(self):
        #NOTE: see how primary functions defined in the "main window" can be called with self.master.[func]
        self.master.frame_change(FirstFrame)
#end of the second frame

class ThirdFrame(tk.Frame):
    def __init__(self, master=None, **kwargs):
        tk.Frame.__init__(self, master, **kwargs)
        #NOTE: see how not changing the title and geometry inherits the main?

        lbl = tk.Label(self, text='Thrid Frame')
        lbl.pack()
        btn = tk.Button(self, text="Back To Main", command=self.frame_goto_main)
        btn.pack()
    
    def frame_goto_main(self):
        self.master.frame_change(FirstFrame)
#end of the second frame

#-----------------------------main loop
if __name__ == "__main__":
    app = RootWindow()
    app.mainloop()