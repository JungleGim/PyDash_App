#screen defines portion of the pydash

#-----------------------------Library Inputs-----------------------------
"""
        button layout
        
        1   |               |   4
            |               |
        2   |    screen     |   5
            |               |
        3   |               |   6

        1- Page up
        2- Settings
        3- Page Down
        4- Scroll up
        5- Enter/select
        6- Scroll Down
"""
dash_btn1 = 15
dash_btn2 = 16
dash_btn3 = 17
dash_btn4 = 18
dash_btn5 = 19
dash_btn6 = 20

#-----------------------------classes-----------------------------
#class for screen control
class screen_info:
    def __init__(self, light_pwm):
        #-----CAN data values
        self.light_pwm = light_pwm          #backlight PWM, in percent
        self.frames = {}                    #

    ''' @brief:     add new frame to dictionary
        @notes:     the {key:value pair} is a {numerical_index : frame} pair
        @return:    (none)
    '''
    def add_frame(self, new_frm):
        self.frames.update({len(self.frames)+1 : new_frm})

    ''' @brief:     add new frame to dictionary
        @notes:     the {key:value pair} is a {numerical_index : frame} pair
                    if the target frame isn't in the list then return None
        @return:    Index of the target frame
    '''
    def get_frm_index(self, tgt_frm):
        for key, val in self.frames:
            if(val == tgt_frm): return key
            else: return None

#default screen values
scrn = screen_info(100)                     #100% PWM backlight

#------------Window or navigation specific functions--------------
