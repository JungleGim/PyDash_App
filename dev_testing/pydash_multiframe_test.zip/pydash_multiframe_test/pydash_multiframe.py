"""
multi window test
------------
test script for setting up the basics of a multi window tk envinronment
Notes
-------------

"""

#-----------------------------imports
from lib import *       #import files as defined in __init__ file of 'lib' directory

#-----------------------------support functions


#-----------------------------init functions


#-----------------------------class for default window
''' @brief: Root window
    @notes: nothing specifically is done here but is the main TK instance
'''
class RootWindow(tk.Tk):
    def __init__(self):
        tk.Tk.__init__(self)
        self.init_wndw()                    #initialize window
        self.goto_frame(Wndw_Gauge0)        #open default frame
    
    def init_wndw(self):
        #----window settings/info
        #self.overrideredirect(True)                         #override direct gets rid of the title bar (fullscreen)
        self.title("Electron Racing Dash")                  #title bar for testing
        disp_res = str(disp_xSz)+'x'+str(disp_ySz)+"+0+0"   #make string for geometry and placement
        self.geometry(disp_res)                             #window size and palcement
        self.maxsize(disp_xSz,disp_ySz)                     #set max size
        self.resizable(False,False)                         #fixed size

        #----display frame
        self.frame = tk.Frame()                             #define the frame object to place things
        self.prev_frame = tk.Frame()                        #define the frame object to place things

        '''
            TODO: Need to confirm HOW this appends the list
                    ~is it alphabetical?
                    ~is it chronological (order listed in py script)?
        '''
        for child in self.winfo_children():                 #iterate through all children
            if isinstance(child, tk.Frame):                 #if its a frame
                scrn.add_frame(child)                       #then append to the list

    #NOTE: the defined functions here can be handled by the frames with master.[func]
    ''' @brief: Go To Frame
        @notes: switches the frame displayed in the root window 
    '''
    def goto_frame(self, new_frame):
        self.prev_frame = self.frame                #save previous frame
        self.frame.pack_forget()                    #delete currrent frame
        self.frame = new_frame(self)                #update to the passed "new_frame"
        self.frame.pack(fill="both", expand=True)   #fill frame to window size
    
    ''' @brief: Frame switch
        @notes: handles the displayed frame state and switches based on inputs
    '''
    def frm_switch(self, btn):
        indx_crnt_frame = scrn.get_frm_index(self.frame)    #get index of the current frame
        '''
        handle frame switching baseed on the pressed button. Have to do a bunch of else-if statements
        here because PyThOn MaTcH sTaTeMeNtS aRe MoRe PoWeRfUl but can't do something fucking
        simple like value matching. All because PEP-635 says that doing something like that doesn't
        "add any more value than a bunch of if/else statements". So. Fucking here we are.
        '''
        if btn == dash_btn1:
            if(self.frame == scrn.frames[0]):                       #if currently at the "first" frame
                self.goto_frame(scrn.frames[len(scrn.frames)])      #wrap around to last frame
            else:
                self.goto_frame(scrn.frames[indx_crnt_frame + 1])   #go to next frame in list
        elif btn == dash_btn2:
            if(self.frame == Wndw_Settings):
                self.goto_frame(self.prev_frame)                    #go "back" to the previous frame
            else:
                self.goto_frame(Wndw_Settings)                      #go to settings frame
        elif btn == dash_btn3:
            if(self.frame == scrn.frames[len(scrn.frames)]):        #if currently at the "last" frame
                self.goto_frame(scrn.frames[0])                     #wrap around to first frame
            else:
                self.goto_frame(scrn.frames[indx_crnt_frame - 1])   #go to previous frame in list
        elif btn == dash_btn4: pass #currently no action
        elif btn == dash_btn5: pass #currently no action
        elif btn == dash_btn6: pass #currently no action
        else:
            self.goto_frame(Wndw_Gauge0)    #default to showing the gauges0 window
#end of the root window          

#-----------------------------class for default gauge display
''' @brief: Gauge 0 frame
    @notes: frame is the primary gauge display
'''
class Wndw_Gauge0(tk.Frame):
    #-----main window initilization
    def __init__(self, master=None, **kwargs):
        tk.Frame.__init__(self, master, **kwargs)
        self.frame_eles()           #place frame elements

    ''' @brief: frame elements
        @param: (none)
        @notes: function contains all the widgets/objects for the default
                window to be displayed
        @retrn: (none)
    '''
    def frame_eles(self):
        capt = drw_func.draw_txt_lbl(self, txt="Main Gauge Window", font=default_font_sm); capt.place(x=100,y=150, height=noPad_height_sm)
#end of main window class

#-----------------------------class for settings frame
''' @brief: Settings frame
    @notes: frame shows all the common configurable items like backlight PWM
'''
class Wndw_Settings(tk.Frame):
    def __init__(self, master=None, **kwargs):
        tk.Frame.__init__(self, master, **kwargs)
        self.frame_eles()           #place frame elements

    ''' @brief: frame elements
        @param: (none)
        @notes: function contains all the widgets/objects for the default
                window to be displayed
        @retrn: (none)
    '''
    def frame_eles(self):
        capt = drw_func.draw_txt_lbl(self, txt="Settings Window", font=default_font_sm); capt.place(x=300,y=150, height=noPad_height_sm)
#end of the settings frame

#-----------------------------class for CAN sniffer frame
''' @brief: CAN sniffer frame
    @notes: frame is a list box with all the RX'd CAN data 
'''
class Wndw_CANsniff(tk.Frame):
    def __init__(self, master=None, **kwargs):
        tk.Frame.__init__(self, master, **kwargs)
        self.frame_eles()           #place frame elements

    ''' @brief: frame elements
        @param: (none)
        @notes: function contains all the widgets/objects for the default
                window to be displayed
        @retrn: (none)
    '''
    def frame_eles(self):
        capt = drw_func.draw_txt_lbl(self, txt="CAN Sniffer Window", font=default_font_sm); capt.place(x=200,y=150, height=noPad_height_sm)
#end of the CAN sniffer frame

#-----------------------------main loop
if __name__ == "__main__":
    app = RootWindow()
    app.mainloop()